var diam1=0;

function setup() {
  createCanvas(400, 400);
  background("#F08080")
}

function draw() {
  
  ellipse(50,100,20,20);
  fill("#FFDAB9") 
  strokeWeight(5);
  ellipse(50,100,diam1,diam1);
  
  fill("#FFFF00");
  ellipse(random(width),random(height),20,20);
  textSize(20);
  textFont("Arial");
  textStyle(ITALIC);
  textAlign(CENTER);
  text("hello:)",40,40);
  console.log(diam1);
}

function mousePressed(){
  if(diam1>50){
    diam1=0;
  }else{
    diam1=diam1+5;  
  }
  }